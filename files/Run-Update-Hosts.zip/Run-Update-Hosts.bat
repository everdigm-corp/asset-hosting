@echo off
powershell -Command "Start-Process powershell -ArgumentList '-NoExit -ExecutionPolicy Bypass -File \"%~dp0Update-Hosts.ps1\"' -Verb RunAs"
