#Requires -RunAsAdministrator
<#
.SYNOPSIS
    Update Windows hosts file.
.DESCRIPTION
    Applies IP/Domain mappings defined in $HostEntries to the hosts file.
    - Domain match + IP match  : No change (SKIP)
    - Domain match + IP differ : Comment out old entry, add new (COMMENT + ADD)
    - No domain + same IP exists : Comment out old entry, add new (COMMENT + ADD)
    - No domain + no IP        : Add new entry (ADD)
.EXAMPLE
    powershell -ExecutionPolicy Bypass -File .\Update-Hosts.ps1
    Run PowerShell as Administrator, then execute this script.
.NOTES
    Must be run as Administrator.
#>

# ============================================================
# Define IP / Domain mappings here
# ============================================================
$HostEntries = @(
    @{ IP = "172.18.100.235";     Domain = "ep.everdigm.mn" }
    # Add more entries as needed
    # @{ IP = "10.0.0.1"; Domain = "another.example.com" }
)
# ============================================================

$HostsPath = "$env:SystemRoot\System32\drivers\etc\hosts"

# Check hosts file exists
if (-not (Test-Path $HostsPath)) {
    Write-Error "hosts file not found: $HostsPath"
    exit 1
}

# Backup original
$BackupPath = "$HostsPath.bak_$(Get-Date -Format 'yyyyMMdd_HHmmss')"
Copy-Item -Path $HostsPath -Destination $BackupPath -Force
Write-Host "[INFO] Backup created: $BackupPath" -ForegroundColor Cyan

# Read hosts file
$lines = [System.Collections.ArrayList]@(Get-Content -Path $HostsPath)

foreach ($entry in $HostEntries) {
    $ip     = $entry.IP.Trim()
    $domain = $entry.Domain.Trim()

    $escapedDomain = [regex]::Escape($domain)
    $domainPattern = "^\s*(\d{1,3}(?:\.\d{1,3}){3})\s+$escapedDomain\s*$"

    $exactMatch = $false

    # Step 1: Match by domain
    for ($i = 0; $i -lt $lines.Count; $i++) {
        if ($lines[$i] -match '^\s*#') { continue }

        if ($lines[$i] -match $domainPattern) {
            $existingIP = $Matches[1]

            if ($existingIP -eq $ip) {
                Write-Host "[SKIP] Already matched: $ip`t$domain" -ForegroundColor Gray
                $exactMatch = $true
            }
            else {
                $originalLine = $lines[$i]
                $lines[$i] = "# [commented by Update-Hosts $(Get-Date -Format 'yyyy-MM-dd')] $originalLine"
                Write-Host "[COMMENT] $originalLine" -ForegroundColor DarkYellow
            }
            break
        }
    }

    if ($exactMatch) { continue }

    # Step 2: Comment out existing entries with same IP but different domain
    $escapedIP = [regex]::Escape($ip)
    $ipPattern = "^\s*$escapedIP\s+\S+"

    for ($i = 0; $i -lt $lines.Count; $i++) {
        if ($lines[$i] -match '^\s*#') { continue }

        if ($lines[$i] -match $ipPattern) {
            $originalLine = $lines[$i]
            $lines[$i] = "# [commented by Update-Hosts $(Get-Date -Format 'yyyy-MM-dd')] $originalLine"
            Write-Host "[COMMENT] $originalLine" -ForegroundColor DarkYellow
        }
    }

    # Add new entry
    $lines.Add("$ip`t$domain") | Out-Null
    Write-Host "[ADD] $ip`t$domain" -ForegroundColor Green
}

# Save hosts file (UTF-8 without BOM)
$sw = New-Object System.IO.StreamWriter($HostsPath, $false, (New-Object System.Text.UTF8Encoding($false)))
foreach ($line in $lines) {
    $sw.WriteLine($line)
}
$sw.Close()

Write-Host ""
Write-Host "[DONE] hosts file updated successfully." -ForegroundColor Cyan

# Flush DNS cache
Write-Host "[INFO] Flushing DNS cache..." -ForegroundColor Cyan
ipconfig /flushdns | Out-Null
Write-Host "[DONE] DNS cache flushed." -ForegroundColor Cyan
